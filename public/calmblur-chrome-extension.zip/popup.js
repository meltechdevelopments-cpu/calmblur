// ============================================================================
// CALMBLUR EXTENSION POPUP (AMO SAFE DOM)
// ============================================================================
(function () {
  const extApi = typeof browser !== "undefined" ? browser : chrome;
  const STORAGE_KEY = "calmblur_ext_settings_v1";

  const settings = {
    enabled: true,
    isPro: false,
    licenseKey: "",
    lastValidatedAt: 0,
    activeCategories: ["emetophobia"],
    actionMode: "blur_mute",
    customWords: []
  };

  function save() {
    const payload = {};
    payload[STORAGE_KEY] = settings;
    extApi.storage.local.set(payload);
  }

  function render() {
    const badge = document.getElementById("planBadge");
    const upLink = document.getElementById("upgradeWebLink");
    document.getElementById("enabledToggle").checked = Boolean(settings.enabled);
    document.getElementById("actionModeSelect").value = settings.actionMode || "blur_mute";

    if (settings.isPro) {
      badge.textContent = "✨ Pass Active";
      badge.classList.add("pro");
      upLink.style.display = "none";
    } else {
      badge.textContent = "Free · 1 Shield";
      badge.classList.remove("pro");
      upLink.style.display = "block";
      if (CALMBLUR_CONFIG.yearlyCheckoutUrl) {
        upLink.href = CALMBLUR_CONFIG.yearlyCheckoutUrl;
      }
    }

    const wrap = document.getElementById("chipsWrap");
    wrap.textContent = "";
    CALMBLUR_ENGINE.TRIGGER_CATEGORIES.forEach(function (cat) {
      const btn = document.createElement("button");
      btn.type = "button";
      const on = settings.activeCategories.indexOf(cat.id) !== -1;
      btn.className = "chip" + (on ? " active" : "");
      btn.textContent = cat.emoji + " " + cat.shortLabel;
      btn.addEventListener("click", function () {
        if (on) {
          if (settings.activeCategories.length > 1) {
            settings.activeCategories = settings.activeCategories.filter(function (x) { return x !== cat.id; });
          }
        } else {
          if (settings.isPro) {
            settings.activeCategories.push(cat.id);
          } else {
            settings.activeCategories = [cat.id];
            document.getElementById("keyMsg").textContent = "Switched free shield to " + cat.shortLabel + ". Activate Pass for all 10 at once!";
          }
        }
        save();
        render();
      });
      wrap.appendChild(btn);
    });
  }

  document.getElementById("enabledToggle").addEventListener("change", function (e) {
    settings.enabled = e.target.checked;
    save();
  });

  document.getElementById("actionModeSelect").addEventListener("change", function (e) {
    if (!settings.isPro && e.target.value !== "blur_mute") {
      e.target.value = "blur_mute";
      document.getElementById("keyMsg").textContent = "Mute-Only & Auto-Skip require an active CalmBlur Pass (£3.99/mo).";
      return;
    }
    settings.actionMode = e.target.value;
    save();
  });

  document.getElementById("activateKeyBtn").addEventListener("click", async function () {
    const val = document.getElementById("keyInput").value.trim();
    const msg = document.getElementById("keyMsg");
    msg.textContent = "Validating key with Polar...";
    const res = await CALMBLUR_CONFIG.validatePolarKey(val);
    if (res.valid) {
      settings.isPro = true;
      settings.licenseKey = val;
      settings.lastValidatedAt = Date.now();
      settings.activeCategories = CALMBLUR_ENGINE.TRIGGER_CATEGORIES.map(function (c) { return c.id; });
      save();
      render();
      msg.textContent = "✅ Pass active! All 10 shields & 5 platforms unlocked.";
    } else {
      msg.textContent = "❌ " + (res.error || "Invalid key.");
    }
  });

  extApi.storage.local.get([STORAGE_KEY], function (res) {
    if (res && res[STORAGE_KEY]) Object.assign(settings, res[STORAGE_KEY]);
    render();
  });
})();
