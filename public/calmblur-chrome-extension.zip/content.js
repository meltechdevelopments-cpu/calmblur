// ============================================================================
// CALMBLUR STREAMING CONTENT SCRIPT (MV3 — SAFE DOM, DRM-SAFE BLUR)
// Supports Netflix, Prime Video, Disney+, YouTube & BBC iPlayer
// ============================================================================
(function () {
  const extApi = typeof browser !== "undefined" ? browser : chrome;
  const STORAGE_KEY = "calmblur_ext_settings_v1";

  let settings = {
    enabled: true,
    isPro: false,
    licenseKey: "",
    lastValidatedAt: 0,
    activeCategories: ["emetophobia"],
    actionMode: "blur_mute",
    customWords: []
  };

  let shieldUntilMs = 0;
  let currentShieldReason = "";
  let currentShieldBlur = true;
  let wasMutedBeforeShield = false;
  let isCurrentlyShielding = false;
  let manualPanicBlur = false;
  let lastCaptionText = "";
  let bannerEl = null;
  let bannerTitleEl = null;
  let bannerSubEl = null;

  const CAPTION_SELECTORS = [
    ".player-timedtext",
    ".player-timedtext-text-container",
    ".atvwebplayersdk-captions-text",
    ".dss-subtitle-renderer-cue",
    ".hive-subtitle-renderer-cue",
    ".ytp-caption-segment",
    ".captions-text",
    ".smp-subtitles",
    "[data-uia='player-timedtext']"
  ].join(",");

  function isNetflixHost() {
    return location.hostname.indexOf("netflix.") !== -1;
  }

  function loadSettings(cb) {
    try {
      extApi.storage.local.get([STORAGE_KEY], function (res) {
        if (res && res[STORAGE_KEY]) {
          Object.assign(settings, res[STORAGE_KEY]);
        }
        if (!settings.isPro && settings.activeCategories.length > 1) {
          settings.activeCategories = [settings.activeCategories[0] || "emetophobia"];
        }
        maybeRevalidateSubscription();
        if (cb) cb();
      });
    } catch (_) {
      if (cb) cb();
    }
  }

  function saveSettings() {
    try {
      const payload = {};
      payload[STORAGE_KEY] = settings;
      extApi.storage.local.set(payload);
    } catch (_) {}
  }

  // Automatic 24h Polar subscription verification (auto-revokes if cancelled)
  async function maybeRevalidateSubscription() {
    if (!settings.isPro || !settings.licenseKey) return;
    if (Date.now() - (settings.lastValidatedAt || 0) < CALMBLUR_CONFIG.recheckIntervalMs) return;

    const check = await CALMBLUR_CONFIG.validatePolarKey(settings.licenseKey);
    if (check.valid) {
      settings.lastValidatedAt = Date.now();
      saveSettings();
    } else if (check.revoked) {
      settings.isPro = false;
      settings.licenseKey = "";
      settings.activeCategories = [settings.activeCategories[0] || "emetophobia"];
      settings.customWords = [];
      saveSettings();
    }
  }

  function getPrimaryVideo() {
    const videos = document.querySelectorAll("video");
    let best = null;
    let bestArea = 0;
    for (let i = 0; i < videos.length; i++) {
      const v = videos[i];
      const rect = v.getBoundingClientRect();
      const area = rect.width * rect.height;
      if (area > bestArea) {
        bestArea = area;
        best = v;
      }
    }
    return best;
  }

  function ensureBanner() {
    const hostParent = document.fullscreenElement || document.body;
    if (!hostParent) return null;

    if (!bannerEl) {
      bannerEl = document.createElement("div");
      bannerEl.id = "calmblur-live-pill";
      bannerEl.style.cssText = [
        "position:fixed",
        "top:22px",
        "right:22px",
        "z-index:2147483646",
        "background:rgba(13,23,30,0.92)",
        "border:1.5px solid #2dd4bf",
        "color:#eef6f8",
        "padding:10px 15px",
        "border-radius:12px",
        "font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif",
        "box-shadow:0 10px 28px rgba(0,0,0,0.45)",
        "max-width:340px",
        "display:none",
        "backdrop-filter:blur(10px)"
      ].join(";");

      bannerTitleEl = document.createElement("div");
      bannerTitleEl.style.cssText = "font-weight:700;font-size:13.5px;color:#2dd4bf;margin-bottom:4px;";

      bannerSubEl = document.createElement("div");
      bannerSubEl.style.cssText = "font-size:12px;color:#cbd5e1;margin-bottom:8px;";

      const btnRow = document.createElement("div");
      btnRow.style.cssText = "display:flex;gap:6px;";

      const skip15Btn = document.createElement("button");
      skip15Btn.type = "button";
      skip15Btn.textContent = "⏭ Skip +15s";
      skip15Btn.style.cssText = "background:#2dd4bf;color:#062825;border:none;border-radius:7px;padding:4px 9px;font-weight:700;font-size:11.5px;cursor:pointer;";
      skip15Btn.addEventListener("click", function () {
        const v = getPrimaryVideo();
        if (v) v.currentTime = Math.min(v.duration || v.currentTime + 15, v.currentTime + 15);
        clearShieldNow();
      });

      const unblurBtn = document.createElement("button");
      unblurBtn.type = "button";
      unblurBtn.textContent = "Show Screen";
      unblurBtn.style.cssText = "background:rgba(255,255,255,0.1);color:#eef6f8;border:1px solid #334155;border-radius:7px;padding:4px 9px;font-size:11.5px;cursor:pointer;";
      unblurBtn.addEventListener("click", function () {
        clearShieldNow();
      });

      btnRow.appendChild(skip15Btn);
      btnRow.appendChild(unblurBtn);
      bannerEl.appendChild(bannerTitleEl);
      bannerEl.appendChild(bannerSubEl);
      bannerEl.appendChild(btnRow);
    }

    if (bannerEl.parentElement !== hostParent) {
      hostParent.appendChild(bannerEl);
    }
    return bannerEl;
  }

  function applyShield(reasonLabel, shouldBlur, durationSec) {
    const v = getPrimaryVideo();
    if (!v) return;

    const holdMs = Math.max(2000, (durationSec || 7) * 1000);
    shieldUntilMs = Math.max(shieldUntilMs, Date.now() + holdMs);
    currentShieldReason = reasonLabel;
    currentShieldBlur = shouldBlur;

    if (!isCurrentlyShielding) {
      wasMutedBeforeShield = Boolean(v.muted);
      isCurrentlyShielding = true;
    }

    v.muted = true;
    if (shouldBlur) {
      v.style.transition = "filter 0.22s ease";
      v.style.filter = "blur(34px) brightness(0.55)";
    }

    const pill = ensureBanner();
    if (pill) {
      bannerTitleEl.textContent = "🛡️ CalmBlur · " + reasonLabel;
      bannerSubEl.textContent = shouldBlur
        ? "Screen frost-blurred & audio muted (Alt+B toggles panic blur)"
        : "Audio cleanly muted";
      pill.style.display = "block";
    }
  }

  function clearShieldNow() {
    manualPanicBlur = false;
    shieldUntilMs = 0;
    const v = getPrimaryVideo();
    if (v && isCurrentlyShielding) {
      v.style.filter = "";
      v.muted = wasMutedBeforeShield;
    }
    isCurrentlyShielding = false;
    if (bannerEl) bannerEl.style.display = "none";
  }

  function checkCaptionsAndTimestamps() {
    if (!settings.enabled) {
      if (isCurrentlyShielding) clearShieldNow();
      return;
    }

    // Free tier works on Netflix; Pro unlocks all 5 streaming platforms
    if (!settings.isPro && !isNetflixHost()) {
      return;
    }

    // 1. Scan active closed-caption DOM nodes
    const nodes = document.querySelectorAll(CAPTION_SELECTORS);
    let combinedText = "";
    for (let i = 0; i < nodes.length; i++) {
      const t = nodes[i].textContent;
      if (t) combinedText += " " + t;
    }
    combinedText = combinedText.trim();

    if (combinedText && combinedText !== lastCaptionText) {
      lastCaptionText = combinedText;
      const hit = CALMBLUR_ENGINE.scanCaptionText(
        combinedText,
        settings.activeCategories,
        settings.isPro ? settings.customWords : []
      );
      if (hit) {
        const mode = settings.isPro ? settings.actionMode : "blur_mute";
        const shouldBlur = mode !== "mute_only" && hit.defaultAction !== "mute_only";
        applyShield(hit.emoji + " " + hit.shortLabel + " Shielded", shouldBlur, hit.holdSeconds);
      }
    }

    // 2. Check curated scene timestamps if page title matches a known film/episode
    const v = getPrimaryVideo();
    if (v && !v.paused && v.currentTime > 0) {
      const matchedTitle = CALMBLUR_ENGINE.matchTitleFromPageString(document.title, []);
      if (matchedTitle) {
        const evalRes = CALMBLUR_ENGINE.evaluatePlaybackSecond(
          matchedTitle,
          v.currentTime,
          settings.activeCategories,
          8
        );
        if (evalRes.state === "active" && evalRes.scene) {
          if (settings.isPro && settings.actionMode === "skip_scene") {
            v.currentTime = evalRes.endSec + 1;
          } else {
            const cat = evalRes.category;
            const shouldBlur = settings.actionMode !== "mute_only" && (!cat || cat.defaultAction !== "mute_only");
            applyShield(
              (cat ? cat.emoji + " " + cat.shortLabel : "Scene") + " Timestamp",
              shouldBlur,
              Math.max(3, evalRes.secondsRemaining)
            );
          }
        }
      }
    }

    // 3. Auto-clear once hold window finishes (unless manual Alt+B Panic Blur is on)
    if (isCurrentlyShielding && !manualPanicBlur && Date.now() > shieldUntilMs) {
      clearShieldNow();
    }
  }

  // Alt + B instant Panic Blur toggle for sudden silent triggers
  window.addEventListener("keydown", function (e) {
    if (e.altKey && (e.key === "b" || e.key === "B")) {
      e.preventDefault();
      if (manualPanicBlur || isCurrentlyShielding) {
        clearShieldNow();
      } else {
        manualPanicBlur = true;
        applyShield("Manual Panic Blur (Alt+B to clear)", true, 3600);
      }
    }
  });

  if (extApi && extApi.storage && extApi.storage.onChanged) {
    extApi.storage.onChanged.addListener(function (changes) {
      if (changes[STORAGE_KEY] && changes[STORAGE_KEY].newValue) {
        Object.assign(settings, changes[STORAGE_KEY].newValue);
        if (!settings.enabled) clearShieldNow();
      }
    });
  }

  loadSettings(function () {
    setInterval(checkCaptionsAndTimestamps, 280);
    const obs = new MutationObserver(function () {
      checkCaptionsAndTimestamps();
    });
    if (document.body) {
      obs.observe(document.body, { childList: true, subtree: true, characterData: true });
    }
  });
})();
